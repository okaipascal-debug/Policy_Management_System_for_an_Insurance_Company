##  The Insurance Products File -  Product Class (product.py)

# This defines what insurance products we sell
# An example is Like creating a menu in a restaurant.

class Product:
    def __init__(self, product_id, name, description, base_premium, coverage_type):
        self.product_id = product_id        # Product code
        self.name = name                    # "Car Insurance"
        self.description = description      # What it covers
        self.base_premium = base_premium    # Basic price
        self.coverage_type = coverage_type  # Type of insurance
    
    def calculate_premium(self, age=0, risk_factor=1.0):
        premium = self.base_premium * risk_factor
        if age > 50:
            premium *= 1.2
        return round(premium, 2)
    
    def display_product_info(self):
        print(f"\n=== Product Information ===")
        print(f"ID: {self.product_id}")
        print(f"Name: {self.name}")
        print(f"Description: {self.description}")
        print(f"Base Premium: ${self.base_premium}")
        print(f"Coverage Type: {self.coverage_type}")