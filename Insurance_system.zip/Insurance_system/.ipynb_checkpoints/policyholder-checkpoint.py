## INSURANCE COMPANY MANAGEMENT SYSTEM
# This system is able to;
# 1. Add customers such as policyholders
# 2. Create insurance products like car insurance, health insurance, etc
# 3. Process payments
# 4. See who bought what


# Therefore, to understand the files structure;
# We think to treat each file like a different department in the company


# insurance_system/
# ├── policyholder.py    → Customer Department
# ├── product.py         → Product Department  
# ├── payment.py         → Accounting Department
# ├── main.py            → Manager's Office
# └── README.md          → Instruction Manual


# Here, they are broken down into clases where each class is like a blue print.
# For example, a car's blueprint can create many actual cars
# Thus, each car has the same parts like engine, wheels etc but different details such color, model etc.


## The Customer File - Policyholder Class (policyholder.py) 

class Policyholder:
    def __init__(self, policyholder_id, name, email, phone):
        # These are like registration form fields
        self.policyholder_id = policyholder_id  # Customer ID
        self.name = name                        # Customer name
        self.email = email                      # Customer email
        self.phone = phone                      # Customer phone
        self.policies = []                      # Empty list for their insurance policies
    
    def add_policy(self, product, payment):
        policy = {
            'product': product,
            'payment': payment,
            'status': 'Active'
        }
        self.policies.append(policy)
        print(f"Policy added for {self.name}")
    
    def display_account_details(self):
        print(f"\n=== Policyholder Details ===")
        print(f"ID: {self.policyholder_id}")
        print(f"Name: {self.name}")
        print(f"Email: {self.email}")
        print(f"Phone: {self.phone}")
        
        if self.policies:
            print(f"\n=== Policies ===")
            for i, policy in enumerate(self.policies, 1):
                print(f"Policy {i}:")
                print(f"  - Product: {policy['product'].name}")
                print(f"  - Premium: ${policy['payment'].amount}")
                print(f"  - Status: {policy['status']}")
        else:
            print("\nNo active policies")


# A simple explanation is when a new customer signs up, we create a "Policyholder" with their details
# For example, self.policies = [] is like an empty folder where we'll store their insurance policies.