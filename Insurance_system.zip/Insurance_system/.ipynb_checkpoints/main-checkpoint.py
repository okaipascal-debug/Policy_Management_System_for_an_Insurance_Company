# MAIN

from policyholder import Policyholder
from product import Product
from payment import Payment

def main():
    print("=== Insurance System Demo ===\n")
    
    # Creating the insurance products
    print("Creating products...")
    car_insurance = Product(
        product_id="PROD001",
        name="Comprehensive Car Insurance",
        description="Full coverage for your vehicle",
        base_premium=1200.00,
        coverage_type="Vehicle"
    )
    
    # Creating the customers
    print("Creating policyholders...")
    amoa = Policyholder(
        policyholder_id="PH001",
        name="Amoa Appiah",
        email="amoa.appiah@email.com",
        phone="555-0101"
    )
    
    # Creating the payment
    print("Creating payments...")
    amoa_payment = Payment(
        payment_id="PAY001",
        amount=1320.00,  # This could be calculated
        payment_method="Credit Card"
    )
    
    # Processing everything
    print("\nProcessing payments...")
    amoa_payment.process_payment()
    
    print("\nAdding policies...")
    amoa.add_policy(car_insurance, amoa_payment)
    
    # Showing results
    print("\n" + "="*50)
    amoa.display_account_details()
    
    print("\n=== Demo Completed ===")

if __name__ == "__main__":
    main()