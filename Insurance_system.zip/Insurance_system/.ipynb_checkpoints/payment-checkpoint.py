## The Payment Processing File - Payment Class (payment.py)

from datetime import datetime

class Payment:
    def __init__(self, payment_id, amount, payment_method, payment_date=None):
        self.payment_id = payment_id  # Payment receipt number
        self.amount = amount          # How much was paid
        self.payment_method = payment_method  # Credit card, cash, etc.
        self.payment_date = payment_date or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.status = "Completed"   # Payment status
    
    def process_payment(self):
        if self.amount > 0:
            self.status = "Completed"
            print(f"Payment of ${self.amount} processed successfully")
            return True
        else:
            self.status = "Failed"
            print("Payment failed: Invalid amount")
            return False
    
    def display_payment_details(self):
        print(f"\n=== Payment Details ===")
        print(f"Payment ID: {self.payment_id}")
        print(f"Amount: ${self.amount}")
        print(f"Method: {self.payment_method}")
        print(f"Date: {self.payment_date}")
        print(f"Status: {self.status}")